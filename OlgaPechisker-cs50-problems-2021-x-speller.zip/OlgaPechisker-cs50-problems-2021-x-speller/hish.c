#include <stdbool.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <cs50.h>
#include <stdint.h>
#include <strings.h>
#include <string.h>

unsigned int hash(const char *word);

int main(void)
{
  char word[46];
  puts("Введите слово: ");
  scanf( "%45s", word); 
  int hashed = hash(word);
  printf("%i\n", hashed); 
}

unsigned int hash(const char *word)
{
    // TODO
    unsigned int sum = 0; 
    for (int j = 0; word[j] != '\0'; j++)
    {
      sum += tolower(word[j]);
    }
    return sum % (9); 
}